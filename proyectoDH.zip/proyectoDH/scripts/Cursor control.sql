
declare
vnumEmpleado propiedad.numempleado%TYPE;
vtotalProp Totpropempleado.TOTPROP%TYPE;
nombreEmp EMPLEADO.NOMBRE%type;
cursor InicializaPropiedadEmpleado
is
select emp.NUMEMPLEADO,emp.NOMBRE , count(pro.NUMEMPLEADO)
from propiedad pro
RIGHT join Empleado emp on pro.NUMEMPLEADO = emp.NUMEMPLEADO

group by emp.NUMEMPLEADO, emp.NOMBRE;
begin
open InicializaPropiedadEmpleado;
loop
fetch
InicializaPropiedadEmpleado
into
vnumEmpleado,nombreEmp,vtotalProp;


exit when InicializaPropiedadEmpleado%NOTFOUND;
dbms_output.put_line(vtotalProp||' '||nombreEmp||' '||vnumEmpleado);
INSERT into TOTPROPEMPLEADO values(vnumempleado,vtotalProp);

end loop;

end;