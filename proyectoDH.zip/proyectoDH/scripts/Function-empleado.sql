--Obtener empleado a cargo de propiedad
CREATE OR REPLACE
FUNCTION fn_Obtener_empleado(f_numpropiedad varchar2)
RETURN varchar2
IS
resultado varchar2(4);
BEGIN
SELECT NUMEMPLEADO INTO resultado
FROM PROPIEDAD
WHERE numpropiedad = f_numpropiedad;

DBMS_OUTPUT.PUT_LINE(resultado);
EXCEPTION
WHEN NO_DATA_FOUND THEN
return 'El numero de propiedad es Invalido';
END;

DECLARE
DATO VARCHAR2(100);
BEGIN
DATO:= fn_Obtener_empleado('PA14');
DBMS_OUTPUT.put_line(DATO);
END;
