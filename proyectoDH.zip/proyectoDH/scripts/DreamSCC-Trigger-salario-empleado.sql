--Un empleado solo puede tener como minimo $250.000 de salario
DROP TRIGGER TG_TOTPROP_Empleado;
CREATE TRIGGER TG_TOTPROP_Empleado
AFTER INSERT OR UPDATE OF TOTPROP
ON EMPLEADO
FOR EACH ROW
WHEN (NEW.TOTPROP =NULL)
BEGIN 
UPDATE EMPLEADO 
SET TOTPROP = 0
where numempleado=:new.numempleado;
END;