/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java_oracle;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.DefaultListModel;
import oracle.jdbc.OracleTypes;

/**
 *
 * @author mariocosta
 */
public class JavaConOracle {

static final String JDBC_DRIVER = "oracle.jdbc.driver.OracleDriver";
static final String DB_URL = "jdbc:oracle:thin:@localhost:1521:xe";
 static final String USERNAME = "dhome";
 static final String PASSWORD = "dhome";
public  void getempleado_con_departamento( DefaultListModel modelo)
    {
        Connection connection = null;
        CallableStatement callableStatement = null;
        try
        {
            /*
             * Register the JDBC driver in DriverManager
             */

            Class.forName(JDBC_DRIVER);

            /*
             * Establish connection to the Database using DriverManager
             */

            connection = DriverManager
                    .getConnection(DB_URL, USERNAME, PASSWORD);

            String plSql = "{call get_empleados_con_propiedades(?,?,?,?)}";

            callableStatement = connection.prepareCall(plSql);

            /*
             * Bind IN and OUT parameters
             */

            callableStatement.registerOutParameter(1, OracleTypes.CURSOR);
            
            callableStatement.registerOutParameter(2, java.sql.Types.VARCHAR);
            callableStatement.registerOutParameter(3, java.sql.Types.INTEGER);
            callableStatement.registerOutParameter(4, java.sql.Types.VARCHAR);
            callableStatement.executeQuery();
            ResultSet rs=(ResultSet)callableStatement.getObject(1);
            

            /*
             * Use execute method to run the stored procedure.
             */

            
//emp.NUMEMPLEADO,emp.NOMBRE , count(pro.NUMEMPLEADO)
            
            while (rs.next())
            {
                modelo.addElement(rs.getString(1)+"-"+rs.getString(2)+" cantidad de propiedades "+rs.getInt(3));
                
                
            }

        }
        catch (SQLException se)
        {
            se.printStackTrace();
        }
        catch (ClassNotFoundException e)
        {
            e.printStackTrace();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        finally
        {
            /*
             * finally block used to close resources
             */
            try
            {
                if (callableStatement != null)
                {
                    callableStatement.close();
                }
            }
            catch (SQLException sqlException)
            {
                sqlException.printStackTrace();
            }
            try
            {
                if (connection != null)
                {
                    connection.close();
                }
            }
            catch (SQLException sqlException)
            {
                sqlException.printStackTrace();
            }
        }
    }

}




