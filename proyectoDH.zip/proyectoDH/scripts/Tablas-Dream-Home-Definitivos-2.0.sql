Drop user DHome Cascade;
Create user DHome identified by dhome;
grant connect to DHome;
grant resource to DHome;


drop table TotPropEmpleado cascade constraints;

drop table ARRIENDO cascade constraints;

drop table CLIENTE cascade constraints;

drop table EMPLEADO cascade constraints;

drop table OFICINA cascade constraints;

drop table PROPIEDAD cascade constraints;

drop table PROPIETARIO cascade constraints;

drop table VISITA cascade constraints;

CREATE TABLE ARRIENDO
  (
    NUMARRIENDO  INTEGER NOT NULL ,
    NUMPROPIEDAD VARCHAR2 (10)NOT NULL ,
    NUMCLIENTE   INTEGER NOT NULL ,
    RENTA INTEGER ,
    FORMAPAGO VARCHAR2 (10) ,
    DEPOSITO INTEGER ,
    PAGADO      VARCHAR2(1) ,
    INICIORENTA DATE ,
    FINRENTA    DATE
  ) ;
ALTER TABLE ARRIENDO ADD CONSTRAINT PK_ARRIENDO PRIMARY KEY ( NUMARRIENDO ) ;
ALTER TABLE ARRIENDO ADD CONSTRAINT ARRIENDO_CLIENTE_FK FOREIGN KEY ( NUMCLIENTE ) REFERENCES CLIENTE ( NUMCLIENTE ) ;
ALTER TABLE ARRIENDO ADD CONSTRAINT ARRIENDO_PROPIEDAD_FK FOREIGN KEY ( NUMPROPIEDAD ) REFERENCES PROPIEDAD ( NUMPROPIEDAD ) ;

CREATE TABLE CLIENTE
  (
    NUMCLIENTE INTEGER NOT NULL ,
    NOMBRE     VARCHAR2 (30) ,
    APELLIDO   VARCHAR2 (30) ,
    DIRECCION  VARCHAR2 (35) ,
    TELEFONO   VARCHAR2 (10) ,
    TIPOPREF   VARCHAR2 (25) ,
    MAXRENT INTEGER
  ) ;
ALTER TABLE CLIENTE ADD CONSTRAINT PK_CLIENTE PRIMARY KEY (NUMCLIENTE) ;

CREATE TABLE EMPLEADO
  (
    NUMEMPLEADO VARCHAR2 (4) NOT NULL ,
    NOMBRE      VARCHAR2 (30) ,
    APELLIDO    VARCHAR2 (30) ,
    CARGO       VARCHAR2 (35) ,
    SEXO        VARCHAR2 (1) ,
    FECHNAC     DATE ,
    SALARIO INTEGER ,
    NUMOFICINA INTEGER,
    TOTPROP INTEGER
  ) ;
ALTER TABLE EMPLEADO ADD CONSTRAINT PK_EMPLEADO PRIMARY KEY ( NUMEMPLEADO ) ;
ALTER TABLE EMPLEADO ADD CONSTRAINT FK_EMPLEADO_REFERENCE_OFICINA FOREIGN KEY ( NUMOFICINA ) REFERENCES OFICINA ( NUMOFICINA ) ON
DELETE CASCADE ;

CREATE TABLE OFICINA
  (
    NUMOFICINA   INTEGER NOT NULL ,
    CALLE        VARCHAR2 (30) ,
    CIUDAD       VARCHAR2 (25) ,
    CODIGOPOSTAL VARCHAR2 (10)
  ) ;
ALTER TABLE OFICINA ADD CONSTRAINT PK_OFICINA PRIMARY KEY ( NUMOFICINA ) ;

CREATE TABLE PROPIEDAD
  (
    NUMPROPIEDAD VARCHAR2 (10) NOT NULL,
    CALLE        VARCHAR2 (30) ,
    CIUDAD       VARCHAR2 (25) ,
    CODIGOPOSTAL VARCHAR2 (10) ,
    TIPO         VARCHAR2 (25) ,
    HAB          INTEGER ,
    RENTA INTEGER ,
    NUMPROPIETARIO VARCHAR2 (4) NOT NULL ,
    NUMEMPLEADO    VARCHAR2 (4)
  ) ;
ALTER TABLE PROPIEDAD ADD CONSTRAINT PK_PROPIEDAD PRIMARY KEY (NUMPROPIEDAD) ;
ALTER TABLE PROPIEDAD ADD CONSTRAINT PROPIEDAD_PROPIETARIO_FK FOREIGN KEY ( NUMPROPIETARIO ) REFERENCES PROPIETARIO ( NUMPROPIETARIO ) ;
ALTER TABLE PROPIEDAD ADD CONSTRAINT FK_PROPIEDA_REFERENCE_EMPLEADO FOREIGN KEY ( NUMEMPLEADO ) REFERENCES EMPLEADO ( NUMEMPLEADO ) ON
DELETE SET NULL ;

CREATE TABLE PROPIETARIO
  (
    NUMPROPIETARIO VARCHAR2 (4) NOT NULL ,
    NOMBRE         VARCHAR2 (30) ,
    APELLIDO       VARCHAR2 (30) ,
    DIRECCION      VARCHAR2 (30) ,
    TELEFONO       VARCHAR2 (10)
  ) ;
ALTER TABLE PROPIETARIO ADD CONSTRAINT PK_PROPIETARIO PRIMARY KEY ( NUMPROPIETARIO );

CREATE TABLE TotPropEmpleado
  (
    NUMEMPLEADO VARCHAR2 (4) NOT NULL ,
    totProp     INTEGER
  ) ;
ALTER TABLE TotPropEmpleado ADD CONSTRAINT PK_TotPropEmpleado PRIMARY KEY ( NUMEMPLEADO ) ;
ALTER TABLE TotPropEmpleado ADD CONSTRAINT FK_TotProp_REFERENCE_EMPLEADO FOREIGN KEY ( NUMEMPLEADO ) REFERENCES EMPLEADO ( NUMEMPLEADO ) ;

CREATE TABLE VISITA
  (
    NUMVISITA INTEGER NOT NULL PRIMARY KEY,
    NUMCLIENTE   INTEGER NOT NULL ,
    NUMPROPIEDAD VARCHAR2 (10) NOT NULL ,
    FECHA        DATE NOT NULL ,
    COMENTARIO   VARCHAR2 (30)
  ) ;
ALTER TABLE VISITA ADD CONSTRAINT PK_VISITA PRIMARY KEY (NUMVISTA) ;
ALTER TABLE VISITA ADD CONSTRAINT FK_VISITA_REFERENCE_CLIENTE FOREIGN KEY ( NUMCLIENTE ) REFERENCES CLIENTE ( NUMCLIENTE ) ;
ALTER TABLE VISITA ADD CONSTRAINT FK_VISITA_REFERENCE_PROPIEDA FOREIGN KEY ( NUMPROPIEDAD ) REFERENCES PROPIEDAD ( NUMPROPIEDAD ) ;


/*==============================================================*/
/* datos: oficina */
/*==============================================================*/
insert into oficina values(005,'16 Holhead','Aberdeem','AB7 5SU');
insert into oficina values(007,'6 Argvill St.','London','NW2');
insert into oficina values(003,'164 Main street','Glasgow','G119Qx');
insert into oficina values(004,'2 Manor Rd','Glasgow','G114Qx');
insert into oficina values(001,'10 Dale Rd','bristol','G12');
insert into oficina values(002,'17 Holhead','Aberdeem','AB7 5SU');
insert into oficina values(008,'7 Argvill St.','London','NW21');
insert into oficina values(006,'163 Main street','Glasgow','G11');
insert into oficina values(010,'2 Manor Rd','Glasgow','G114x');
insert into oficina values(011,'14 Dale Rd','bristol','G2');
insert into oficina values(017,'6 Argvill St.','London','W2');
insert into oficina values(013,'166 Main street','Glasgow','9Qx');
insert into oficina values(014,'3 Manor Rd','Glasgow','Qx');
insert into oficina values(012,'11 Dale Rd','bristol','GH2');
insert into oficina values(015,'Costanera 25','Valdivia','0324');
insert into oficina values(115,'Picarte 124','Valdivia','0324');
insert into oficina values(215,'El Morro 110','Arica','10300');
insert into oficina values(315,'El Vergel 1500','Arica','123123');
insert into oficina values(415,'Av. Walker Martinez 1360','Santiago','W101');
insert into oficina values(515,'Av. Antonio Varas 929','Santiago','W101');



/*==============================================================*/
/* datos: cliente */
/*==============================================================*/
insert into cliente values(76,'Jhon','Kay','56 High ST,Londonn,SW14EH','0207774563','Departamento',450);
insert into cliente values(56,'Aline','Stewart','64 Fern Dr, Glasgow G42 OBL','0141324182','Departamento',350);
insert into cliente values(74,'Mike','Ritchie','63 Well St, Glasgow,G42','0141943742','Casa',750);
insert into cliente values(62,'Mary','Tregear','12 Park PI, Glasgow, G40QR','0141225742','Departamento',600);
insert into cliente values(78,'Juan','Kayser','55 High ST,Londonn,SW14EH','0207774564','Departamento',450);
insert into cliente values(57,'Alicia','Soto','63 Fern Dr,. GlasgowG42 OBL','0141324183','Departamento',350);
insert into cliente values(72,'Miguel','Torres','62 Well St, Glasgow,G42','0141943740','Casa',750);
insert into cliente values(63,'Maria','Perez','13 Park PI, Glasgow,G4 0QR','0141225741','Departamento',600);


/*==============================================================*/
/* datos: empleado */
/*==============================================================*/
insert into empleado values('SL21','Jhon','White','Gerente','M','01/10/45',300000,005,NULL);
insert into empleado values('SG37','Peter','Denver','Asistente','M','10/11/60',120000,006,NULL);
insert into empleado values('SG14','David','Ford','Supervisor','M','09/09/58',180000,003,NULL);
insert into empleado values('SA9','Mary','Lee','Asistente','F','17/09/59',90000,007,NULL);
insert into empleado values('SG5','Susan','Sarandon','Gerente','F','21/03/60',240000,003,NULL);
insert into empleado values('SL41','Julie','Roberts','Asistente','F','13/06/63',90000,005,NULL);
insert into empleado values('SL22','Juan','Blanco','Gerente','M','01/10/44',300000,005,NULL);
insert into empleado values('SG36','Luis','Jara','Asistente','M','10/11/61',120000,003,NULL);
insert into empleado values('SG13','David','Gates','Supervisor','M','09/09/58',180000,003,NULL);
insert into empleado values('SA8','Maria','Bombal','Asistente','F','17/09/59',90000,007,NULL);
insert into empleado values('SG4','Susana','Sarandons','Gerente','F','21/03/60',240000,003,NULL);
insert into empleado values('SL40','James','Bond','Asistente','F','13/06/63',90000,005,NULL);
insert into empleado values('SL50','Juan','Perez','Vendedor','M','13/06/63',151000,015,NULL);
insert into empleado values('SL60','Jaime','Soto','Vendedor','M','14/06/83',350000,115,NULL);
insert into empleado values('SL70','Julia','Berne','Vendedor','F','23/01/53',200000,215,NULL);
insert into empleado values('SL55','Jorge','Fernandez','Vendedor','M','13/06/63',151000,015,NULL);
insert into empleado values('SL65','Jose','Isla','Vendedor','M','14/06/83',350000,115,NULL);


/*==============================================================*/
/* datos: Propietario */
/*==============================================================*/
insert into propietario values('C046','Joe','Keogh','2 Fergus Dr, AberdeenAB 7SX','0122486121');
insert into propietario values('C087','Carol','Farrel','6 Achray St.Glasgow, G32 9DX','0141357741');
insert into propietario values('C040','Tina','Murphy','63 Well St, Glasgow, G42','0141943742');
insert into propietario values('C093','Tony','Shaw','12 Park PI, Glasgow, G40QR','0141225742');
insert into propietario values('C047','Jose','Casanova','El Volvan 123, Santiago AB 7SX','0122486125');
insert into propietario values('C088','Carolina','Fernandez','Macul 1800. Santiago, G32 9DX','0141357741');
insert into propietario values('C041','Cristina','Mora','Av. Matta 1800, Santiago, G42','0141943752');
insert into propietario values('C094','Tomas','Figueroa','Av. Macul 120, Santiago, G40QR','0141225542');


/*==============================================================*/
/* datos: PROPIEDAD */
/*==============================================================*/
insert into PROPIEDAD values('PA14','16 Holhead','Aberdeem','AB7 5SU','Casa',6,650,'C046','SL21');
insert into PROPIEDAD values('PL94','6 Argvill St.','London','NW2','Departamento',4,400,'C087','SL21');
insert into PROPIEDAD values('PG4' ,'6 Lawrence St','Glasgow','G119QX','Departamento',3,350,'C040','SA9');
insert into PROPIEDAD values('PG36','2 Manor Rd','Glasgow','G114QX','Departamento',3,375,'C093','SA9');
insert into PROPIEDAD values('PG21','AV. Matta 150','Santiago','G12','Casa',5,600,'C087','SG5' );
insert into PROPIEDAD values('PR01','Macul 120 ','Santaigo','G129AX','Departamento',4,450,'C093','SA8');
insert into PROPIEDAD values('PR02','Macul 220','Santiago','G129AX','Departamento',5,550,'C093','SG13');
insert into PROPIEDAD values('PR03','Macul 420','Santiago','G129AX','Departamento',6,650,'C093','SG14');
insert into PROPIEDAD values('PR04','Macul 620','Santiago','G129AX','Departamento',3,350,'C093','SG36');
insert into PROPIEDAD values('PR05','Loa 100','Santiago','G129AX','Departamento',2,250,'C093','SG4');
insert into PROPIEDAD values('PG16','Arturo Prats 250','Santiago','G129AX','Departamento',4,450,'C047','SL22');
insert into PROPIEDAD values('PR07','Gorbea 200','Santiago','G129AX', 'Departamento',6,650,'C047','SL40');
insert into PROPIEDAD values('PR08','Gomez 230','Santiago','G129AX', 'Departamento',2,250,'C041','SL41');
insert into PROPIEDAD values('PR09','Garibaldi 1500','Santiago','G129AX', 'Departamento',6,650,'C041','SL50');
insert into PROPIEDAD values('PR10','Las Urbinas 210','Santiago','G129AX', 'Departamento',6,650,'C094','SL55');
insert into PROPIEDAD values('PR11','Lastarria 1400','Santiago','G129AX', 'Departamento',3,350,'C094','SL60');
insert into PROPIEDAD values('PR12','Las Giraldas 200','Santiago','G129AX','Departamento',4,450,'C093','SL70');


/*==============================================================*/
/* datos: VISITA */
/*==============================================================*/
insert into visita values(001,56,'PA14','24-11-1999','muy peque�o');
insert into visita values(002,62,'PA14','14-11-1999','no tiene sal�n');
insert into visita values(003,76,'PG4','20-10-1999','muy lejos');
insert into visita values(004,72,'PG16','24-06-2007','Bakan');
insert into visita values(005,72,'PG36','24-06-2007','Super');
insert into visita values(006,62,'PG16','25-06-2007','Cool');
insert into visita values(007,62,'PG4','25-06-2007', NULL);
insert into visita values(008,62,'PG36','25-06-2007','No salva');
insert into visita values(009,72,'PG4','25-06-2007',NULL);
insert into visita values(010,56,'PG36','28-10-1999',NULL);
insert into visita values(011,56,'PG4','26-11-1999',NULL);

/*==============================================================*/
/* datos: ARRIENDO*/
/*==============================================================*/
insert into arriendo values(10024,'PA14',62,650,'Visa',1300,'Y','01-06-2005','31-05-2006');
insert into arriendo values(10075,'PL94',76,400,'Contado',800,'N','01-08-2005','31-01-2006');
insert into arriendo values(10012,'PG21',74,600,'Cheque',1200,'Y','01-07-2005','30-06-2006');
/*==============================================================*/


