/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dreamhome;

import CONTROLADOR.ConexionEM;
import CONTROLADOR.PropiedadJpaController;
import MODELO.Empleado;
import MODELO.Propiedad;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java_oracle.JavaConOracle;
import javax.persistence.EntityManager;
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Francisco
 */
public final class MantenedorPropiedad extends javax.swing.JFrame {

    ArrayList<Propiedad> propiedad;
   // PropiedadDB db = new PropiedadDB();
    EntityManager con =  ConexionEM.getConexion();
   int seleccionado=0;
       
    PropiedadJpaController  control_propiedad = new PropiedadJpaController();
    Propiedad p=null;
    /**
     * Creates new form MantenedorPropiedad
     */
    public MantenedorPropiedad() {
      
        initComponents();
        DefaultListModel modelo= new DefaultListModel();
        lista.setModel(modelo);
        
        CrearModelotblPropiedad();
        LimpiarFormulario();
        this.setResizable(false);
        this.setLocationRelativeTo(null);
    }

public void LimpiarFormulario(){
    DefaultTableModel tb = (DefaultTableModel)tblPropiedad.getModel();
    for (int i = tb.getRowCount()-1; i >= 0; i--) {
        tb.removeRow(i);
    }
}
public boolean Eliminar_propiedad(String id){
    con.getTransaction().begin();
    Propiedad p=con.find(Propiedad.class, id);
    boolean eliminado=false;
    if (p!=null) {
        eliminado=true;
    }
    con.remove(p);
    con.getTransaction().commit();
    return eliminado;
    
}

public void Editar(){
    
     if (seleccionado!=-1) {
          if (!con.getTransaction().isActive()) {
               con.getTransaction().begin();
         }
          
            Empleado e= con.find(Empleado.class, (String)tblPropiedad.getValueAt(seleccionado,8));
            if (e!=null) {
            p=new Propiedad();
            p.setNumpropiedad((String)tblPropiedad.getValueAt(seleccionado,0));
            p.setCalle((String)tblPropiedad.getValueAt(seleccionado,1));
            
            p.setCiudad((String)tblPropiedad.getValueAt(seleccionado,2));
            p.setCodigopostal((String)tblPropiedad.getValueAt(seleccionado,3));
            p.setTipo((String)tblPropiedad.getValueAt(seleccionado,4));
            p.setHab(new BigInteger(tblPropiedad.getValueAt(seleccionado,6).toString()));
            p.setRenta(new BigInteger(tblPropiedad.getValueAt(seleccionado,5).toString()));
            p.setNumpropietario((String)tblPropiedad.getValueAt(seleccionado,7));
            
            p.setNumempleado(e);
            }
           
            
        }
    if (p!=null) {
            txtNumPropiedad.setText(p.getNumpropiedad().toString());
            txtDireccion.setText(p.getCalle());
            txtCiudad.setText(p.getCiudad());
            txtCodPostal.setText(p.getCodigopostal());
            txtTipo.setText(p.getTipo());
            txtRenta.setText(p.getRenta().toString());
            txtNumHab.setText(p.getHab().toString());
            txtNumPropietario.setText(p.getNumpropietario());
            txtNumEmpleado.setText(p.getNumempleado().getNumempleado());
           
            txtNumEmpleado.setEditable(false);
            txtNumEmpleado.setEditable(false);
            
    }
}

public void Actualizar(){
   if (!con.getTransaction().isActive()){
       con.getTransaction().begin();
   }
    
    if (camposLLenos()&&p!=null) {
        p=null;
         Empleado e=con.find(Empleado.class, txtNumEmpleado.getText());
        if (e!=null) {
            p=null;
            
            p=con.find(Propiedad.class, txtNumPropiedad.getText());
            if (p!=null) {
                
             
             //p.setNumpropiedad(txtNumPropiedad.getSelectedText());
             p.setCalle(txtDireccion.getText());
             p.setCiudad(txtCiudad.getText());
             p.setCodigopostal(txtCodPostal.getText());
             p.setTipo(txtTipo.getText());
             p.setRenta(new BigInteger(txtRenta.getText()));
             p.setHab(new BigInteger(txtNumHab.getText()));
             p.setNumpropietario(txtNumPropietario.getText());
             //p.setNumempleado(e);
            con.getTransaction().commit();
            txtNumEmpleado.setEditable(true);
            txtNumEmpleado.setEditable(true);
            LimpiarCampos();
            Llenartabla();
           JOptionPane.showMessageDialog(null,"Propiedad Nº "+txtNumPropiedad.getText()+" Ediatdo con Exito ","Editar Propiedad",JOptionPane.INFORMATION_MESSAGE);
            p=null;
            }else{
                JOptionPane.showMessageDialog(null,"Propiedad Nº "+txtNumPropiedad.getText()+" No se puedo Editar ","Editar Propiedad",JOptionPane.ERROR_MESSAGE);
                p=null;
            }
            
        

       
        
        }else{
           JOptionPane.showMessageDialog(null,"Propiedad Nº "+txtNumPropiedad.getText()+" No se puedo Editar ","Editar Propiedad",JOptionPane.ERROR_MESSAGE);
           p=null;
        }
       
    }
            
           
           
          
    
}

public boolean camposLLenos(){
    boolean lleno=false;
    if (txtDireccion.getText().trim()!="") {
    lleno=true;
    }
    if ( txtCiudad.getText().trim()!="") {
    lleno=true;
    }
    if (txtCodPostal.getText().trim()!="") {
    lleno=true;
    }
    if (txtTipo.getText().trim()!="") {
    lleno=true;
    }
    if (txtRenta.getText().trim()!="") {
    lleno=true;
    }
    if (txtNumHab.getText().trim()!="") {
    lleno=true;
    }
    if (txtNumPropietario.getText().trim()!="") {
    lleno=true;
    }
    if (txtNumEmpleado.getText().trim()!="") {
    lleno=true;
    }
    if (txtNumPropiedad.getText().trim()!="") {
    lleno=true;
    }
    
    return lleno;
    
}

public void limpiar_campos(){
      boolean lleno=false;
    if (txtDireccion.getText().trim()!="") {
    lleno=true;
    }
    if ( txtCiudad.getText().trim()!="") {
    lleno=true;
    }
    if (txtCodPostal.getText().trim()!="") {
    lleno=true;
    }
    if (txtTipo.getText().trim()!="") {
    lleno=true;
    }
    if (txtRenta.getText().trim()!="") {
    lleno=true;
    }
    if (txtNumHab.getText().trim()!="") {
    lleno=true;
    }
    if (txtNumPropietario.getText().trim()!="") {
    lleno=true;
    }
    if (txtNumEmpleado.getText().trim()!="") {
    lleno=true;
    }
    if (txtNumPropiedad.getText().trim()!="") {
    lleno=true;
    }
}
    public void LimpiarCampos(){
     txtDireccion.setText("");
    
   
     txtCiudad.setText("");
    
   
    txtCodPostal.setText("");
    
   
    txtTipo.setText("");
    
   
    txtRenta.setText("");
   
   
    txtNumHab.setText("");

   
    txtNumPropietario.setText("");
  
   
    txtNumEmpleado.setText("");
  
   
    txtNumPropiedad.setText("");
} 


   /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel3 = new javax.swing.JPanel();
        jTabbedPane5 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        lista = new javax.swing.JList<>();
        Buscar = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        lblNumProp = new javax.swing.JLabel();
        txtNumPropietario = new javax.swing.JTextField();
        lblRenta = new javax.swing.JLabel();
        txtRenta = new javax.swing.JTextField();
        lblNumEmp = new javax.swing.JLabel();
        txtNumEmpleado = new javax.swing.JTextField();
        lblNumPr = new javax.swing.JLabel();
        txtNumPropiedad = new javax.swing.JTextField();
        lblCodPostal = new javax.swing.JLabel();
        txtCodPostal = new javax.swing.JTextField();
        txtTipo = new javax.swing.JTextField();
        lblNumHab = new javax.swing.JLabel();
        txtNumHab = new javax.swing.JTextField();
        lblDireccion = new javax.swing.JLabel();
        txtDireccion = new javax.swing.JTextField();
        lblCiudad = new javax.swing.JLabel();
        txtCiudad = new javax.swing.JTextField();
        lblTipo = new javax.swing.JLabel();
        Botones = new javax.swing.JPanel();
        btnIngresarPropiedad = new javax.swing.JButton();
        btnActualizarProp = new javax.swing.JButton();
        btnBuscarPropiedad = new javax.swing.JButton();
        btnEliminarPropiedad = new javax.swing.JButton();
        btnListar = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblPropiedad = new javax.swing.JTable();

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Propiedades");

        lista.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane2.setViewportView(lista);

        Buscar.setText("Buscar");
        Buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BuscarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 439, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Buscar))
                .addContainerGap(568, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Buscar)
                .addContainerGap(470, Short.MAX_VALUE))
        );

        jTabbedPane5.addTab("FUNCIONES ORACLE", jPanel1);

        lblNumProp.setText("N° Propietario");

        lblRenta.setText("Renta");

        txtRenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtRentaActionPerformed(evt);
            }
        });

        lblNumEmp.setText("N° Empleado");

        lblNumPr.setText("N° Propiedad");

        lblCodPostal.setText("Cod. Postal");

        lblNumHab.setText("N° de Hab");

        lblDireccion.setText("Direccion");

        lblCiudad.setText("Ciudad");

        lblTipo.setText("Tipo");

        btnIngresarPropiedad.setText("Ingresar");
        btnIngresarPropiedad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIngresarPropiedadActionPerformed(evt);
            }
        });

        btnActualizarProp.setText("Actualizar");
        btnActualizarProp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarPropActionPerformed(evt);
            }
        });

        btnBuscarPropiedad.setText("Buscar");

        btnEliminarPropiedad.setText("Eliminar");
        btnEliminarPropiedad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarPropiedadActionPerformed(evt);
            }
        });

        btnListar.setText("Listar");
        btnListar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnListarActionPerformed(evt);
            }
        });

        jButton1.setText("Editar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout BotonesLayout = new javax.swing.GroupLayout(Botones);
        Botones.setLayout(BotonesLayout);
        BotonesLayout.setHorizontalGroup(
            BotonesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(BotonesLayout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(btnIngresarPropiedad)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
                .addComponent(btnListar, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnActualizarProp, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnBuscarPropiedad)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnEliminarPropiedad)
                .addGap(79, 79, 79))
        );
        BotonesLayout.setVerticalGroup(
            BotonesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(BotonesLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(BotonesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, BotonesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnListar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnActualizarProp, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(BotonesLayout.createSequentialGroup()
                        .addGroup(BotonesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnBuscarPropiedad, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnEliminarPropiedad, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(btnIngresarPropiedad, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );

        tblPropiedad.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "N° Propiedad", "Direccion", "Ciudad", "Codigo Postal", "Tipo", "N° de Hab", "Renta", "N° Propietario", "N° Empleado"
            }
        ));
        tblPropiedad.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblPropiedadMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblPropiedad);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addComponent(lblDireccion)
                                .addGap(37, 37, 37))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(lblTipo)
                                    .addComponent(lblCiudad))
                                .addGap(47, 47, 47)))
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtDireccion, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtCiudad, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtTipo, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 263, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(lblNumEmp)
                                        .addComponent(lblNumPr))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(lblNumProp)
                                        .addGap(2, 2, 2)))
                                .addGap(22, 22, 22)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtNumPropiedad, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtNumEmpleado, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(85, 85, 85)
                                .addComponent(txtNumPropietario, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(48, 48, 48)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(lblCodPostal)
                                .addGap(18, 18, 18)
                                .addComponent(txtCodPostal, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(lblRenta)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(txtRenta, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(Botones, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(86, 86, 86)
                        .addComponent(lblNumHab))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(207, 207, 207)
                        .addComponent(txtNumHab, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(lblNumProp)
                                            .addComponent(txtNumPropietario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(4, 4, 4)
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(lblNumEmp)
                                            .addComponent(txtNumEmpleado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addComponent(lblDireccion))
                                .addGap(18, 18, 18))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(txtDireccion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(12, 12, 12)))
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblNumPr)
                            .addComponent(txtNumPropiedad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblCiudad)
                            .addComponent(txtCiudad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblRenta)
                            .addComponent(txtRenta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(30, 30, 30)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblCodPostal)
                            .addComponent(txtCodPostal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(27, 27, 27)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblTipo)
                    .addComponent(txtTipo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(82, 82, 82)
                .addComponent(lblNumHab)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 23, Short.MAX_VALUE)
                .addComponent(txtNumHab, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(Botones, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(143, 143, 143)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jTabbedPane5.addTab("CRUD", jPanel2);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jTabbedPane5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 20, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jTabbedPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 638, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 11, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tblPropiedadMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblPropiedadMouseClicked
        // TODO add your handling code here:
        //0 numPropiedad
        //1 direc
        //2 ciudad
        //3 codigopost
        //4 tipo
        //5 renta
        //6 hab
        //7numPropietario
        //8 num emplpeado
        seleccionado=tblPropiedad.rowAtPoint(evt.getPoint());
    }//GEN-LAST:event_tblPropiedadMouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here
        Editar();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void btnListarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnListarActionPerformed
        LimpiarFormulario();
        Llenartabla();
    }//GEN-LAST:event_btnListarActionPerformed

    private void btnEliminarPropiedadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarPropiedadActionPerformed
        // TODO add your handling code here:
        if (Eliminar_propiedad(txtNumPropiedad.getText())) {
            JOptionPane.showMessageDialog(null,"Propiedad Nº "+txtNumPropiedad.getText()+" Eliminado ","Eliminar Propiedad",JOptionPane.INFORMATION_MESSAGE);

        }else
        {
            JOptionPane.showMessageDialog(null,"Propiedad Nº "+txtNumPropiedad.getText()+" NO se pudo Eliminar","Eliminar Propiedad",JOptionPane.ERROR_MESSAGE);

        }
    }//GEN-LAST:event_btnEliminarPropiedadActionPerformed

    
    private void btnActualizarPropActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarPropActionPerformed
        // TODO add your handling code here:
        Actualizar();
    }//GEN-LAST:event_btnActualizarPropActionPerformed

    private void btnIngresarPropiedadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIngresarPropiedadActionPerformed
        Propiedad prd =  new Propiedad();

        Empleado empleado = null;
        String  numemple = null;

        numemple = txtNumEmpleado.getText();

        empleado = con.find(Empleado.class, numemple);
        if (empleado != null) {
            Propiedad p = new Propiedad();

            p.setNumpropiedad(txtNumPropiedad.getText());
            p.setCalle(txtDireccion.getText());
            p.setCiudad(txtCiudad.getText());
            p.setCodigopostal(txtCodPostal.getText());
            p.setTipo(txtTipo.getText());
            p.setHab(new BigInteger(txtNumHab.getText()));
            p.setRenta(new BigInteger(txtRenta.getText()));
            p.setNumpropietario(txtNumPropietario.getText());
            p.setNumempleado(empleado);

            con.getTransaction().begin();
            con.persist(p);
            con.getTransaction().commit();
            JOptionPane.showMessageDialog(null,"Propiedad Nº "+txtNumPropiedad.getText()+" Ingresada ","Ingresar Propiedad",JOptionPane.INFORMATION_MESSAGE);
            System.out.println("Guardado");
        }else{
            JOptionPane.showMessageDialog(null,"Propiedad Nº "+txtNumPropiedad.getText()+" Ingresado ","Ingresar Propiedad",JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnIngresarPropiedadActionPerformed

    private void txtRentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtRentaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtRentaActionPerformed

    private void BuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BuscarActionPerformed
        // TODO add your handling code here:
        
        DefaultListModel modelo= new DefaultListModel();
        lista.setModel(modelo);
        
        
       java_oracle.JavaConOracle JO=new JavaConOracle();
       JO.getempleado_con_departamento(modelo);
        
        
        
        
    }//GEN-LAST:event_BuscarActionPerformed

    public static DefaultTableModel modelo2;
    private void CrearModelotblPropiedad(){
    try {
    modelo2 = (new DefaultTableModel(
        null, new String [] {
        "NumPropiedad","Direccion","Ciudad","Codigo Postal",
        "Tipo","Renta","Habitaciones","NumPropietario","NumEmpleado"}){
        Class[] types = new Class [] {
        java.lang.String.class,
        java.lang.String.class,
        java.lang.String.class,
        java.lang.String.class,
        java.lang.String.class,
        java.lang.String.class,
        java.lang.String.class,
        java.lang.String.class,
        java.lang.String.class
        };
        boolean[] canEdit = new boolean [] {
        false,false,false,false,false,false,false,false,false
        };
        @Override
        public Class getColumnClass(int columnIndex) {
        return types [columnIndex];
        }
        @Override
        public boolean isCellEditable(int rowIndex, int colIndex){
        return canEdit [colIndex];
        }
        });
        tblPropiedad.setModel(modelo2);
        } catch (Exception e) {
        JOptionPane.showMessageDialog(null,e.toString()+"error2");
        }
        }
    
    private void Llenartabla(){
        try {
            Object prop[]= null;
            List<Propiedad> listPropiedad;
            
            listPropiedad = control_propiedad.findPropiedadEntities();
            
            for (int i = 0; i < listPropiedad.size(); i++) {
                modelo2.addRow(prop);
                modelo2.setValueAt(listPropiedad.get(i).getNumpropiedad(), i, 0);
                modelo2.setValueAt(listPropiedad.get(i).getCalle(), i, 1);
                modelo2.setValueAt(listPropiedad.get(i).getCiudad(), i, 2);
                modelo2.setValueAt(listPropiedad.get(i).getCodigopostal(), i, 3);
                modelo2.setValueAt(listPropiedad.get(i).getTipo(), i, 4);
                modelo2.setValueAt(listPropiedad.get(i).getRenta(), i, 5);
                modelo2.setValueAt(listPropiedad.get(i).getHab(), i, 6);
                modelo2.setValueAt(listPropiedad.get(i).getNumpropietario(), i, 7);
                modelo2.setValueAt(listPropiedad.get(i).getNumempleado().getNumempleado(), i, 8); 
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
       //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MantenedorPropiedad.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MantenedorPropiedad.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MantenedorPropiedad.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MantenedorPropiedad.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
            
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new MantenedorPropiedad().setVisible(true);
            
        });
        
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Botones;
    private javax.swing.JButton Buscar;
    private javax.swing.JButton btnActualizarProp;
    private javax.swing.JButton btnBuscarPropiedad;
    private javax.swing.JButton btnEliminarPropiedad;
    private javax.swing.JButton btnIngresarPropiedad;
    private javax.swing.JButton btnListar;
    private javax.swing.JButton jButton1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTabbedPane jTabbedPane5;
    private javax.swing.JLabel lblCiudad;
    private javax.swing.JLabel lblCodPostal;
    private javax.swing.JLabel lblDireccion;
    private javax.swing.JLabel lblNumEmp;
    private javax.swing.JLabel lblNumHab;
    private javax.swing.JLabel lblNumPr;
    private javax.swing.JLabel lblNumProp;
    private javax.swing.JLabel lblRenta;
    private javax.swing.JLabel lblTipo;
    private javax.swing.JList<String> lista;
    private javax.swing.JTable tblPropiedad;
    private javax.swing.JTextField txtCiudad;
    private javax.swing.JTextField txtCodPostal;
    private javax.swing.JTextField txtDireccion;
    private javax.swing.JTextField txtNumEmpleado;
    private javax.swing.JTextField txtNumHab;
    private javax.swing.JTextField txtNumPropiedad;
    private javax.swing.JTextField txtNumPropietario;
    private javax.swing.JTextField txtRenta;
    private javax.swing.JTextField txtTipo;
    // End of variables declaration//GEN-END:variables
}
